package henrikbn.projekt2015_02_18;

/**
 * Created by Henrik on 19-02-2015.
 */
public class ModelType
{
	public static final String DISTRIBUTOR = "distributor";
	public static final String PRODUCT = "product";
	public static final String PURCHASE = "purchase";
	public static final String SHOPPINGLIST = "shoppingList";
	public static final String DEFAULT = "none";
}
